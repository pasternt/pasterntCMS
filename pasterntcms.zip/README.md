pasterntCMS
===========
pasterntCMS is an OpenSource CMS, currently in Closed-Beta. It offers an simple site- and usermananagement with a very small size. It uses the Bootstrap 3 Framework (http://getbootstrap.com/) for frontend and the Foundation 4 Framework (http://foundation.zurb.com/) for the ACP. It is around 400 files big and easy to install. 
