<?php

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Zugriff verweigert</title>
    </head>
    <body>
        <h1>Zugriff verweigert</h1>
        <hr>
        <p>Der Zugriff zu der gew&uuml;nschten Ressource wurde verweigert.</p>
        <small>Powered by pasterntCMS</small>
        
    </body>
</html>
