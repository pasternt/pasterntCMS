<?php
    function footer()
    {
        echo '<div class="row"><div class="large-12 columns"><div class="panel"><center>pasterntCMS | <a href="http://pasternt-cms.de/" target="_blank">Herstellerseite besuchen</a></center></div></div></div>';
    }
?>